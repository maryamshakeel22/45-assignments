// Question no 9
// Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message.
var favNum = 8;
var message2 = " because it is my lucky number ";
console.log("".concat(favNum, " ").concat(message2, "."));
