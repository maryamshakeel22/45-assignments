// Question no 9

// Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message.

let favNum:number=8
let message2:string=" because it is my lucky number."
console.log(`${favNum} ${message2}`)