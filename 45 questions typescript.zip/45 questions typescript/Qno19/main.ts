// Question no 19

// Dinner Guests: Working with one of the programs from Exercises 14 through 18, print a message indicating the number of people you are inviting to dinner.

let guest3:string[]=["Ambreen","Alisha","Aisha","Oma"]
console.log(`you are inviting ${guest3.length} people to dinner`)