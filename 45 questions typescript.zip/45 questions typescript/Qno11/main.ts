// Question no 11

// Names: Store the names of a few of your friends in a array called names. Print each person’s name by accessing each element in the list, one at a time.

let arrayname:string[]=["Ambreen","Oma","Aisha Eman"]
console.log(arrayname[0])
console.log(arrayname[1])
console.log(arrayname[2])