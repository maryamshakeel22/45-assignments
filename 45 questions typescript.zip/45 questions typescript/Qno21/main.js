"use strict";
// Question no 21
// They think of something you could store in a TypeScript Object. Write a program that creates Objects containing these items.
let student = {
    Name: "Maryam",
    Age: 16,
    Rollnumber: 437996,
    Course: "Artificial intelligence",
    Center: "Governor House Karachi"
};
console.log(student);
