"use strict";
// Question no 20
// Think of something you could store in a array. For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. Write a program that creates a list containing these items.
console.log('list of languages:');
let languages = ["Urdu", "English", "Chinese", "Punjabi", "Balochi"];
languages.map((items) => (console.log(items)));
