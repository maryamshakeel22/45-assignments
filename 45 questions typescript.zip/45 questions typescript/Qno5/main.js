"use strict";
// Question no 5
// Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.
let famous_person = "Sir Francis Bacon";
let message = "knowledge is power";
console.log(`${famous_person} said, "${message}"`);
