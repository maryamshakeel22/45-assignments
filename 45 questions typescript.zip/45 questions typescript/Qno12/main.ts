// Question no 12

// Greetings: Start with the array you used in Exercise 11, but instead of just printing each person’s name, print a message to them. The text of each message should be the same, but each message should be personalized with the person’s name.

let arrayName:string[]=["Hadia","Arzoo","Jameela","Sumama"]
let message3:string=" I am inviting you for dinner"
console.log(arrayName[0]+message3)
console.log(arrayName[1]+message3)
console.log(arrayName[2]+message3)
console.log(arrayName[3]+message3)